Crude but stealthy adblocker for youtube on chrome. When it detects an add it reloads the page and restores your progress through the video. Its a chrome extention so to use it just download the files into a folder... Then go to youtubechrome://extensions/ Enable developer mode Then click 'load unpacked' and select the folder. I hope you enjoy the theme and adfree videos :)

Please address any ethics related enquires to www.chatgpt.com

pls xmr 86XeJYscdWFQ5VDvpKzcAeAUfoA6AG5wP5RpkyWH4xZvJziLfBkQk1B2ub8XJHzSoQi27AxGdQcnh2r2nGK1iRzGSovivb8